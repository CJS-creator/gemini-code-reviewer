
import { GoogleGenAI } from "@google/genai";
import { GEMINI_MODEL_NAME, GEMINI_PROMPT_TEMPLATE } from '../constants';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set. Please ensure it's available.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const reviewCodeWithGemini = async (code: string, language: string): Promise<string> => {
  const languageLabel = language.charAt(0).toUpperCase() + language.slice(1); // e.g. Python
  const prompt = GEMINI_PROMPT_TEMPLATE
    .replace(/\[LANGUAGE\]/g, languageLabel)
    .replace(/\[LANGUAGE_LOWERCASE\]/g, language.toLowerCase())
    .replace(/\[CODE_PLACEHOLDER\]/g, code);

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      // No thinkingConfig, default is fine for this task.
      // No specific systemInstruction in config, it's part of the main prompt.
    });
    
    // The .text property directly gives the string output.
    const textResponse = response.text;
    if (!textResponse) {
        throw new Error('Gemini API returned an empty response.');
    }
    return textResponse;

  } catch (error) {
    console.error('Gemini API call failed:', error);
    if (error instanceof Error) {
        // Check for common API errors
        if (error.message.includes('API key not valid')) {
            throw new Error('Invalid API Key. Please check your API_KEY environment variable.');
        }
        if (error.message.includes('quota')) {
            throw new Error('API quota exceeded. Please check your Gemini API usage.');
        }
    }
    throw new Error(`Failed to get review from Gemini: ${error instanceof Error ? error.message : String(error)}`);
  }
};
    