
import React, { useState, useCallback } from 'react';
import { ReviewResult } from '../types';
import { Button } from './Button';
import { Icon } from './Icon';

interface ReviewPanelProps {
  reviewResult: ReviewResult;
}

export const ReviewPanel: React.FC<ReviewPanelProps> = ({ reviewResult }) => {
  const [copied, setCopied] = useState(false);

  const handleCopyCode = useCallback(() => {
    navigator.clipboard.writeText(reviewResult.revisedCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy code: ', err);
      // Optionally show an error message to the user
    });
  }, [reviewResult.revisedCode]);

  // Basic markdown-to-HTML for feedback. For robust solution, a library would be better.
  const formatFeedback = (text: string) => {
    let html = text;
    // Bold: **text** or __text__
    html = html.replace(/\*\*(.*?)\*\*|__(.*?)__/g, '<strong>$1$2</strong>');
    // Italic: *text* or _text_
    html = html.replace(/\*(.*?)\*|_(.*?)_/g, '<em>$1$2</em>');
    // Inline code: `code`
    html = html.replace(/`(.*?)`/g, '<code class="bg-slate-700 px-1 py-0.5 rounded text-sm text-sky-300">$1</code>');
    // Lists (simple unordered)
    html = html.replace(/^\s*-\s+(.*)/gm, '<li class="ml-4 list-disc">$1</li>');
    html = html.replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>'); // Wrap LIs in UL
     // Newlines to <br>
    html = html.replace(/\n/g, '<br />');
    return { __html: html };
  };


  return (
    <div className="space-y-6 flex flex-col h-full">
      <div>
        <h3 className="text-xl font-semibold text-sky-400 mb-2">Feedback</h3>
        <div 
          className="bg-slate-900/70 p-4 rounded-lg border border-slate-700 max-h-80 overflow-y-auto prose prose-sm prose-invert prose-p:text-slate-300 prose-strong:text-slate-100 prose-em:text-slate-200 prose-code:text-sky-300 prose-li:text-slate-300"
          dangerouslySetInnerHTML={formatFeedback(reviewResult.feedback)}
        />
      </div>
      
      <div className="flex-grow flex flex-col">
        <div className="flex justify-between items-center mb-2">
            <h3 className="text-xl font-semibold text-sky-400">
                Revised Code 
                {reviewResult.language && <span className="text-sm font-normal text-slate-400 ml-2">({reviewResult.language})</span>}
            </h3>
            <Button onClick={handleCopyCode} variant="secondary" size="sm" className="!py-1.5 !px-3">
                <Icon name={copied ? "check" : "copy"} className="w-4 h-4 mr-1.5" />
                {copied ? 'Copied!' : 'Copy Code'}
            </Button>
        </div>
        <pre className="bg-slate-900 p-4 rounded-lg border border-slate-700 text-sm flex-grow overflow-auto min-h-[200px]">
          <code className={`language-${reviewResult.language || 'plaintext'} block whitespace-pre-wrap break-all`}>
            {reviewResult.revisedCode}
          </code>
        </pre>
      </div>
    </div>
  );
};
    