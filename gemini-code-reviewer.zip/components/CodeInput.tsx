
import React from 'react';

interface CodeInputProps {
  value: string;
  onChange: (value: string) => void;
  language: string; // Can be used for future syntax highlighting hints
  placeholder?: string;
}

export const CodeInput: React.FC<CodeInputProps> = ({ value, onChange, placeholder }) => {
  return (
    <div className="flex-grow flex flex-col">
      <label htmlFor="code-input" className="block text-sm font-medium text-slate-300 mb-1">
        Your Code
      </label>
      <textarea
        id="code-input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder || "Enter your code here..."}
        className="w-full flex-grow bg-slate-900 border border-slate-700 text-slate-200 rounded-lg shadow-sm p-4 font-mono text-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none resize-none min-h-[300px] lg:min-h-[400px] transition-colors duration-150"
        spellCheck="false"
      />
    </div>
  );
};
    