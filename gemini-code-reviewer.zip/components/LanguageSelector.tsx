
import React from 'react';
import { LanguageOption } from '../types';

interface LanguageSelectorProps {
  selectedLanguage: string;
  onLanguageChange: (language: string) => void;
  languages: LanguageOption[];
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({ selectedLanguage, onLanguageChange, languages }) => {
  return (
    <div>
      <label htmlFor="language-select" className="block text-sm font-medium text-slate-300 mb-1">
        Select Language
      </label>
      <select
        id="language-select"
        value={selectedLanguage}
        onChange={(e) => onLanguageChange(e.target.value)}
        className="w-full bg-slate-700 border border-slate-600 text-slate-200 rounded-lg shadow-sm focus:ring-sky-500 focus:border-sky-500 py-2.5 px-3 text-sm transition-colors duration-150"
      >
        {languages.map((lang) => (
          <option key={lang.value} value={lang.value} className="bg-slate-700 text-slate-200">
            {lang.label}
          </option>
        ))}
      </select>
    </div>
  );
};
    